package characters;

import java.io.Serializable;
import java.util.Random;

import map.Position;

/**
* Classe représentant un monstre dans le jeu.
* Elle hérite de la classe abstraite LivingBeing et implémente Serializable.
*/
public class Monster extends LivingBeing  implements Serializable{

	private String name;
	private static final long serialVersionUID = -3404980670336256759L;
	public static final String[] names = {
            "Vorgothrax", "Grimloch", "Necrognash", "Shadowmaw", "Drakulisk", 
            "Ghoulrot", "Doomclaw", "Frostbite", "Bloodfeaster", "Nightshade",
            "Darkling", "Gloomfang", "Abysscrawler", "Cursedwraith", "Hellspawn",
            "Deathshroud", "Moonhowler", "Netherbeast", "Chaosfiend", "Ebonclaw",
            "Necrosphinx", "Skullcrusher", "Soulripper", "Demonlord", "Voidwalker",
            "Blackscale", "Dreadfiend", "Shadowreaper", "Gravechaser", "Wraithlord",
            "Gorgonite", "Nightstalker", "Grimrot", "Darkspine", "Doomweaver",
            "Bloodfang", "Shadebiter", "Sorrowmire", "Deathclaw", "Cryptspawn",
            "Hellwraith", "Nightterror", "Echolurker", "Shadowbeast", "Necrosiren",
            "Demonspawn", "Gloomhowler", "Bonechiller", "Soulcrusher", "Dreadmaw"};
	
	
    /**
     * Constructeur de la classe Monster.
     * @param _pos La position du monstre.
     */
	public Monster(Position _pos) {
		super(5, generateName());
		this.pos = _pos;
	}

    /**
     * Constructeur de la classe Monster.
     * @param _name Le nom du monstre.
     * utile lorsque le maître du jeu souhaite créer un monstre
     */
	public Monster(String _name) {
		super(5, _name);
	}
	
    /**
     * Méthode appelée lorsque le monstre meurt.
     */
	@Override
	public void mourir() {
		System.out.println("\u001B[36mCame the sword's strike upon the \u001B[31mcreature\u001B[36m, followed by a final resounding \u001B[31mroar\u001B[36m throughout the chamber, "
				+ "as the \u001B[31mbeast\u001B[36m was banished to the depths of hell.\u001B[0m\r\n");
		
	}
	
	  /**
     * Génère un nom aléatoire pour le monstre à partir de la liste prédéfinie de noms.
     * @return Le nom généré pour le monstre.
     */
	public static String generateName() {
		Random random = new Random();
		return names[random.nextInt(names.length)];
	}
	
	
}
