package characters;

import java.io.Serializable;

import map.Position;

/**
 * Classe abstraite représentant un être vivant dans le jeu.
 * Elle implémente Serializable.
 */
public abstract class LivingBeing implements Serializable{

	private static final long serialVersionUID = -173779227559134302L;
	private int HP;
	private String name;
	protected Position pos;
	private static final int damages = 0;
	
	/**
     * Constructeur de la classe LivingBeing.
     * @param _HP Les points de vie de l'être vivant.
     * @param _name Le nom de l'être vivant.
     */
	public LivingBeing(int _HP, String _name) {
		this.HP = _HP;
		this.name = _name;
	}
	
	/**
     * Méthode abstraite appelée lorsque l'être vivant meurt.
     */
	public abstract void mourir();
	
	   /**
     * Réduit les points de vie de l'être vivant en fonction des dégâts reçus.
     * @param _damage Les dégâts infligés.
     */
	public void takeDamage(int _damage) {
		this.HP -= _damage;
		System.out.print(this.getColoredName() + " staggered back");
		if (this.HP > 0) {
			System.out.println(", but managed to steady himself and remain in the fight.");
		} else {
			System.out.println(" and fell to their knees, too weakened to continue the fight.");
			mourir();
		}
		
	}
	 /**
     * Vérifie si l'être vivant est en vie.
     * @return true si l'être vivant est en vie, sinon false.
     */
	public boolean isAlive() {
		return this.HP > 0;
	}
	
	public int getHP() {
		return HP;
	}
	
	public String getName() {
		return this.name;
	}
	
	   /**
     * Obtient le nom de l'être vivant avec la couleur correspondante.
     * @return Le nom de l'être vivant avec la couleur correspondante.
     */
	public String getColoredName() {
		if (this instanceof Man) {
			return ("\u001B[34m" + name + "\u001B[0m") ;
		}
		return ("\u001B[31m" + name + "\u001B[0m");
	}
	
	
	

	public Position getPos() {
		return pos;
	}

	public void setHP(int hP) {
		HP = hP;
	}

	public void setPos(int _x, int _y) {
		this.pos.setX(_x);
		this.pos.setY(_y);
	}
	
	
}
