package characters;

import java.io.Serializable;

import map.Door;
import map.Maze;
import map.Room;
import view.keyboard;

public class DungeonMaster implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3012231327814425651L;
	private Maze maze;
	
	/**
     * Constructeur de la classe DungeonMaster.
     *
     * @param _maze le labyrinthe dans lequel le Maître du Donjon opère.
     */
	public DungeonMaster(Maze _maze) {
		this.maze = _maze;
		
	}
	
	/**
     * Ajoute un monstre dans une salle spécifiée du labyrinthe.
     *
     * @param _roomId l'identifiant de la salle où ajouter le monstre.
     */
	public void addMonster(int _roomId) {
		int answer = 0;
		Room currentRoom = findRoom(_roomId);
		System.out.println("Would like to create your own monster or add a random one from the pool ? (tap 1 to create or tap 2 to add)");
		while (answer < 1 || answer > 2) {
			System.out.println("Error : out of bound");
			answer = keyboard.enterKeyboardInt();
		}
		if (answer == 1) {
			System.out.print("Name of the monster : ");
			String name = keyboard.enterKeyboardString();
			
			currentRoom.setMonster(new Monster(name));
		} else 
			currentRoom.setMonster(new Monster(currentRoom.getPos()));
		
		System.out.println("A new monster appeared in the room " + _roomId + ". His name is " + currentRoom.getMonster().getColoredName());
	}
	
	
	/**
     * Recherche et renvoie la salle correspondant à un identifiant donné.
     *
     * @param _roomId l'identifiant de la salle recherchée.
     * @return la salle correspondant à l'identifiant spécifié, ou null si aucune salle ne correspond.
     */
	private Room findRoom(int _roomId) {
		for (int i = 0; i < this.maze.getRow(); i++) {
			for (int j = 0; j < this.maze.getRow(); j++) {
				if (this.maze.getMaze()[i][j].getId() == _roomId) {
					return this.maze.getMaze()[i][j];
				}
			}
		}
		System.out.println("Error : no rooms match with this id");
		return null;
	}
/*
	public void delMonster(int _roomId) {
		_room.setMonster(null);
	}
	
	public void openDoor(int _roomId, String _direction) {
		for (Door d : _room.getDoors()) {
			if (d.getDirection().equals(_direction)) {
				d.setClosed(false);
			}
		}
	}
	
	public void closeDoor(Room _room, String _direction) {
		for (Door d : _room.getDoors()) {
			if (d.getDirection().equals(_direction)) {
				d.setClosed(true);
			}
		}
	}
	*/
	
}
