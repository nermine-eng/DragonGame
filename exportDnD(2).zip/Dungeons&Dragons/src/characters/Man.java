package characters;

import java.io.Serializable;

import loot.Armor;
import loot.Equipement;
import loot.TypeEquipment;
import loot.Weapon;
import map.Position;
import map.Room;
import view.keyboard;

/**
 * La classe `Man` représente un personnage dans le jeu. Elle étend la classe `LivingBeing` et implémente l'interface `Serializable`.
 */
public class Man extends LivingBeing implements Serializable{
	
	private static int MaxHP = 10;
	private static final long serialVersionUID = 4187166744759987777L;
	private int monsterKilled = 0, roomExplored = 1;
	private Weapon weapon;
	private Armor armor;
	private boolean isEquipedW = false, isEquipedA = false;


	 /**
     * Constructeur de la classe Man.
     * @param _HP Les points de vie du personnage.
     * @param _name Le nom du personnage.
     */
	public Man(int _HP, String _name) {
		super(_HP, _name);
		this.weapon = null;
		this.armor = null;
		this.pos = new Position(0, 0);
		//System.out.println(toString());
		//showStats();
	}
	
	/**
     * Permet au personnage de parler un message.
     * @param message Le message à prononcer.
     * @return Le message prononcé par le personnage.
     */
	public String parler(String message) {
		return this.getName() + " : " + message;
	}
	
	  /**
     * Méthode appelée lors de la mort du personnage.
     * Affiche un message de fin de partie.
     */
	public void mourir() {
		System.out.println("The adventurer's journey has come to an end. \r\nHe fought valiantly against the dangers of the maze, "
				+ "but alas, it proved too much for them. \r\nHis memory will live on as a brave and daring explorer. who dared to take on the treacherous depths of the labyrinth.");
	}
	
	
	  /**
     * Demande au joueur dans quelle direction il souhaite se déplacer.
     * @return La direction choisie par le joueur (N, E, S ou W).
     */
	public String move() {
		System.out.println("The adventurer confronts four doors, each a portal to a different realm.\r"
				+ "which way are you gonna take ? (N, E, S or W)");
		String direction = keyboard.enterKeyboardString();
		boolean sortir = (direction.equals("N")) || (direction.equals("E")) || (direction.equals("S")) || (direction.equals("W"));
		while (!sortir) {
			direction = keyboard.enterKeyboardString();
			sortir = ((direction.equals("N")) || (direction.equals("E")) || (direction.equals("S")) || (direction.equals("W")));
		}
		return direction;
	}
	
	
	/**
     * Permet au joueur d'ouvrir une porte dans une direction donnée.
     * Met à jour la position du joueur en fonction de la direction.
     * @param _room La salle actuelle du joueur.
     * @param direction La direction de la porte à ouvrir.
     */
	public void openDoor(Room _room, String direction) {
		int x = this.getPos().getX(), y = this.getPos().getY();
		switch (direction) {
			case "N" :
				x--;
				break;
			case "E" :
				y++;
				break;
			case "S" :
				x++;
				break;
			case "W" :
				y--;
				break;
		}
		this.setPos(x, y);
	}

	
	  /**
     * Permet au joueur d'attaquer un monstre.
     * Réduit les points de vie du monstre en fonction des dégâts du joueur.
     * @param _monster Le monstre à attaquer.
     */
	public void attack(Monster _monster) {
		int damage = 1;
		this.weapon.use();
		System.out.println("durée de vie de l'arme --> " + this.weapon.getDurability() + " Points de dégats de l'arme ---> " + this.weapon.getDamage());
		if (this.weapon.isDestroyed())
			System.out.println("My faithful sword shattered upon the relentless assault of my foe, leaving me defenseless and unprepared for further conflict.");
			damage = this.weapon.getDamage();
			this.setEquipedW(false);
			this.setWeapon(null);
		_monster.takeDamage(damage);
	}
	
	
    /**
     * Permet au joueur de tenter de s'échapper d'un combat.
     * Demande au joueur s'il souhaite fuir ou non.
     * @return true si le joueur décide de fuir, false sinon.
     */
	public boolean escape() {
		System.out.println("You have \033[31m" + this.getHP() + "\033[0m left.\rYou could choose to retreat from this battle, and live to fight another day. ? (1 for yes or 2 for no)");
		int answer = keyboard.enterKeyboardInt();
		while (answer < 1 && answer > 2) {
			System.out.println("Error : out of bound");
			answer = keyboard.enterKeyboardInt();
		}
		if (answer == 1) {
			return true;
		}
		return false;
	}
	
	
	 /**
     * Méthode appelée lors de la victoire du joueur.
     * Augmente les statistiques du joueur et affiche un message de victoire.
     */
	public void winner() {
		System.out.println("\u001B[1m\u001B[42m\u001B[34mVictory\u001B[40m\u001B[0m in battle floods one with a surge of power, and the \u001B[32mhealing embrace\u001B[0m of that triumph \u001B[32m\u001B[4mwashes away all wounds.\u001B[0m");
		this.MaxHP++;
		this.setHP(MaxHP);
		this.monsterKilled++;
		this.roomExplored++;
		System.out.println();
		showStats();
	}
	
	
	 /**
     * Affiche les statistiques du joueur (nom, points de vie, etc.).
     */
	public void showStats() {
		String space = "						";
		System.out.println(space +"+------------------+");
		System.out.println(space +"|       STATS      |");
		System.out.println(space +"+------------------+");
		if (this.getName().length() < 4) {
			System.out.println(space + "| Name : \u001B[0m" + this.getName() + "       |");
		} else {
			System.out.println(space +"| Name : " + this.getName().substring(0,4) + "      |");
		}
		System.out.println(space +"| HP : " + this.getHP() + "          |");
		if (this.monsterKilled >= 10)
			System.out.println(space +"| KILLS : " + this.getMonsterKilled() + "       |");
		else
			System.out.println(space +"| KILLS : " + this.getMonsterKilled() + "        |");
		System.out.println(space +"| " + this.getPos().toString() + "|");
		System.out.println(space +"+------------------+\n");
	}

	
	   /**
     * Équipe un équipement (arme ou armure) récupéré par le joueur.
     * Si le joueur avait déjà un équipement du même type, il est déséquipé.
     * @param _loot L'équipement à équiper.
     */
	public void equipStuff(Equipement _loot) {
		if (_loot instanceof Weapon) {
			if (this.isEquipedW) {
				desequipStuff(TypeEquipment.WEAPON);
			}
			this.weapon = (Weapon) _loot;
			this.isEquipedW = true;
			this.weapon.setOwner(this);
		} else {
			if (this.isEquipedA) {
				desequipStuff(TypeEquipment.ARMOR);
			}
			this.armor = (Armor) _loot;
			this.isEquipedA = true;
			this.armor.setOwner(this);
		}
		
	}
	
	/**
     * Inflige des dégâts au joueur en fonction de l'attaque d'un ennemi.
     * Si le joueur porte une armure, celle-ci peut réduire les dégâts subis.
     * Si l'armure est détruite, le joueur la perd.
     * @param _damage Les dégâts infligés par l'ennemi.
     */
	public void takeDamage(int _damage) {
		if (this.isEquipedA) {
			System.out.println("Your " + this.armor.getColoredName() + " \u001B[92mprevent you from taking damage\u001B[0m");
			this.armor.use();
			if (this.armor.isDestroyed()) {
				System.out.println("Your armor shattered upon the devastating blow of my enemy's strike, leaving you vulnerable and exposed to further attacks.");
				this.armor = null;
				this.isEquipedA = false;
			}
		} else {
			super.takeDamage(_damage);
		}
	}
	
	
	 /**
     * Affiche l'équipement actuel du joueur (arme et armure).
     */
	public void showEquipment() {
	    if (isEquipedA && isEquipedW) {
	        System.out.println("You are wearing a " + this.armor.getColoredName() +
	                " and you're fighting with " + this.weapon.getColoredName() + ".");
	    } else if (!isEquipedA && isEquipedW) {
	        System.out.println("You are not wearing an armor and you're fighting with " + this.weapon.getColoredName() + ".");
	    } else if (isEquipedA && !isEquipedW) {
	        System.out.println("You are wearing a " + this.armor.getColoredName() +
	                " and you're fighting without a sword.");
	    } else {
	        System.out.println("You don't have any stuff at this moment!\n");
	    }
	}

	
	   /**
     * Déséquipe un équipement (arme ou armure) porté par le joueur.
     * @param type Le type d'équipement à déséquiper.
     */
	public void desequipStuff(TypeEquipment type) {
		if (type.equals(TypeEquipment.WEAPON)) {
			System.out.println("You dropped down your loyal weapon " + this.weapon.getName() + " on the ground");
			this.weapon.setOwner(null);
			this.weapon = null;
			this.isEquipedW = false;
		} else {
			System.out.println("You dropped down your lifesaver armor " + this.armor.getName() + " on the ground");
			this.armor.setOwner(null);
			this.armor = null;
			this.isEquipedA = false;
		}
	}
	
	public Weapon getWeapon() {
		return weapon;
	}


	public Armor getArmor() {
		return armor;
	}


	public int getMonsterKilled() {
		return monsterKilled;
	}


	public int getRoomExplored() {
		return roomExplored;
	}
	
	public boolean isEquipedW() {
		return isEquipedW;
	}


	public void setWeapon(Weapon weapon) {
		this.weapon = weapon;
	}


	public void setArmor(Armor armor) {
		this.armor = armor;
	}


	public void setEquipedW(boolean isEquipedW) {
		this.isEquipedW = isEquipedW;
	}


	public boolean isEquipedA() {
		return isEquipedA;
	}


	public void setEquipedA(boolean isEquipedA) {
		this.isEquipedA = isEquipedA;
	}

	@Override
	public String toString() {
		return "Man [monsterKilled=" + monsterKilled + ", roomExplored=" + roomExplored + ", weapon=" + weapon
				+ ", armor=" + armor + ", isEquipedW=" + isEquipedW + ", isEquipedA=" + isEquipedA + "]";
	}


}
