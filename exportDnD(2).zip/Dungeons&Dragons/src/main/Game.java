package main;

import java.io.Serializable;
import java.util.Random;

import characters.Man;
import characters.Monster;
import loot.Equipement;
import loot.Weapon;
import map.Maze;
import map.Room;
import characters.DungeonMaster;
import view.keyboard;

/**
 * La classe Game représente le jeu principal.
 * Elle gère le déroulement du jeu, les interactions avec le joueur et le maître du donjon, ainsi que la sauvegarde et le chargement de la partie.
 */
public class Game implements Serializable {

	private static final long serialVersionUID = 4187166744759980256L;
	private Maze maze;
	private boolean isNewGame = false;
	private Room[][] map;
	private Room currentRoom;


	private Man adventurer;
	private int difficulty = 0;
	private int entrance = 0;

	
	/**
	 * Méthode principale qui lance le jeu.
	 */
	public void play() {
		int monstersKilled = 0, roomsExplored = 1, entrance = 0;
		boolean escape = false;
		Equipement loot = null;

		/*
		 * ---------------------------------------------------------------------------
		/* ***************************** CHOIX GAMEPLAY ******************************/
		
		welcomeMessage(); // On affiche le message d'accueil
		int modeChoice = displayChoices(); // On affiche les choix possibles (joueur ou maitre de donjon)
		// Ici on a choisit d'être le MJ
		if (modeChoice == 2) {
			// DungeonMaster
			
			
			
			int mazeChoice = displayMazeChoice();
			this.maze = new Maze(mazeChoice);
			this.setDifficulty(mazeChoice);
			
			Man player = new Man(10, "Player1");
			DungeonMaster DM = new DungeonMaster(maze);
			this.currentRoom = this.maze.getMaze()[0][mazeChoice];
			
			showSolution(new Man(999, "Dmj"), mazeChoice);
			System.out.println();
			
			int roomToModified = displayRoomChoices();
			
			int action = displayDungeonMasterChoices(); // Action que le maitre du jeu a choisi de faire
			
			switch (action) {
				case 1 :
					DM.addMonster(roomToModified);
					break;
				case 2 :
					break;
				case 3 :
					break;
				case 4 :
					break;
				case 5 :
					break;
				case 6 :
					break;
				case 7 :
					break;
				case 8 :
					break;
					
			}
			
			
			SaveGame.saveGame(this, "save.dat"); // On enregistre les modifications du maitre du jeu pour que le joueur puisse jouer sur la nouvelle partie.
		
		} else { // partie joueur
			
			modeChoice = displayAdventurerChoices();
			
			// choic de load ou de jouer sur une nouvelle partie
			if (modeChoice == 2) {
				
				Game loadedGame = LoadGame.loadGame("save.dat");
				int hp = 10;
				loadedGame.solveMaze(loadedGame.adventurer, modeChoice, loadedGame.currentRoom);
				loadedGame.theEnd(loadedGame.adventurer, loadedGame.maze, 150000, false);
				hp = loadedGame.adventurer.getHP();
			} else {

				this.adventurer = createCharacter(); // Création personnage
				this.difficulty = difficultyChoice();// Choix difficulté
				this.maze = new Maze(difficulty); // Création du labyrinthe
				
				
				//showSolution(adventurer, difficulty);
				
				entrance = difficulty;
				long start = System.currentTimeMillis(); // Lancement du compteur de temps

				

				
				System.out.println(
						"The adventurer pushes open the door and steps tentatively into the first room, their eyes adjusting to the dim lighting. \r\nThe room is sparsely furnished, with only a small table and chair in the center. \r\nAs they take a few cautious steps forward, "
								+ "the door behind them shuts with a resounding thud, leaving them alone in the eerie silence of the maze.");
				
				this.currentRoom = this.maze.getEntrance(); // Au début on commence dans la salle centrale du premier
															// étage
				adventurer.setPos(0, entrance);// on déplace notre personnage dessus
				
/*
				/* ---------------------------------------------------------------------------
				/* *************************** DEBUT + BOUCLE JEU ****************************/
				
				// Tant que le boss de fin n'a pas été battu et que l'aventurier a encore des
				// points de vie
				
				solveMaze(this.adventurer, this.difficulty, this.currentRoom);
				
				
				/* ---------------------------------------------------------------------------
				/* ******************************* FIN DU JEU ********************************/
				long end = System.currentTimeMillis();
				long time = end - start;
				theEnd(adventurer, maze, time, false);
			}
				
		}
	}
	


	
	private int displayRoomChoices() {
		String space = "			";
		String line = space + "***********************************************************************";
		System.out.println(line);
		System.out.println(space +"* which room do you want to modify ? (enter id)        		           *");
		System.out.println(line);
		System.out.println();
		int choice = keyboard.enterKeyboardInt();
		while (choice < 1 || choice > this.maze.getSize() - 1) {
			System.out.println("retry : out of bound");
			choice = keyboard.enterKeyboardInt();
		}
		return choice;
	}




	private int displayMazeChoice() {
		String space = "			";
		String line = space + "***********************************************************************";
		System.out.println(line);
		System.out.println(space +"* which maze do you want to modify ?         		              *");
		System.out.println(space +"*   \u001B[1m1. Small\u001B[0m 						              *");
		System.out.println(space +"*   \u001B[1m2. Medium\u001B[0m 		    				              *");
		System.out.println(space +"*   \u001B[1m3. Large\u001B[0m 		   				              *");
		System.out.println(line);
		System.out.println();
		int choice = keyboard.enterKeyboardInt();
		while (choice < 1 && choice > 3) {
			System.out.println("retry : out of bound");
			choice = keyboard.enterKeyboardInt();
		}
		return choice;
	}



	/* ---------------------------------------------------------------------------
	/* ***************************** CREATION PERSO ******************************/
	/**
	 * Crée un personnage en demandant le nom à l'utilisateur.
	 * @return Le personnage créé.
	 */
	public Man createCharacter() {
		System.out.println(
			"Greetings adventurer! You have found yourself in a treacherous maze. The path ahead is unclear \r"
					+ "and the walls seem to shift and change as you move. Once you step inside, there may be no turning back. \r"
					+ "A voice calls out to you, what's your name adventurer ?");
		keyboard.enterKeyboardString();
		String name = keyboard.enterKeyboardString();
		return new Man(10, name);
	}
	
	
	/* ---------------------------------------------------------------------------
	/* **************************** CHOIX DIFFICULTE *****************************/
	/**
	 * Permet au joueur de choisir la difficulté du jeu.
	 * @return La difficulté choisie par le joueur.
	 */
	public int difficultyChoice() {
		int entrance = 0;
		System.out.println(
				"Before you loom three doors, each evoking its own unique and formidable presence. The first door \r"
						+ "appears" + " \u001B[32msolid and unremarkable\u001B[0m"
						+ ", giving off an air of \u001B[32msecurity\u001B[0m\r. "
						+ "The second door \u001B[33memanates a faint but welcoming warmth\u001B[0m, accompanied by the gentle sound of \u001B[33mrushing water\u001B[0m \r"
						+ "beyond its threshold\r. "
						+ "However, the last door presents a \u001B[31mdaunting challenge\u001B[0m, shrouded as it is in billowing smoke and foreboding \r"
						+ "shadows. Although it may be the \u001B[31mmost difficult\u001B[0m of the three to pass, it also promises the greatest rewards. \r"
						+ " Which door will you select ? (1, 2 or 3)");
		int difficulty = keyboard.enterKeyboardInt();

		while (difficulty < 0 || difficulty > 3) {
			System.out.println("You only have 3 choices : 1, 2 or 3");
			difficulty = keyboard.enterKeyboardInt();
		}
		// On affiche un texte d'entrée différent selon la difficulté
		switch (difficulty) {
		case 1:
			System.out.println(
					"\u001B[1mYou push open\u001B[0m the first door and \u001B[1mstep into\u001B[0m a \u001B[2mdimly lit\u001B[0m room. The \u001B[2mair\u001B[0m is \u001B[2mstale\u001B[0m, and the \u001B[2mwalls\u001B[0m are \u001B[2madorned\u001B[0m with \u001B[2mcobwebs\u001B[0m.\n"
							+ "You \u001B[1mfeel\u001B[0m a \u001B[1msense of relief\u001B[0m as you \u001B[1mrealize\u001B[0m the \u001B[1mpath ahead\u001B[0m seems \u001B[1mrelatively safe\u001B[0m, at least for now.\n");
			break;
		case 2:
			System.out.println(
					"You choose the second door, and as you cross the threshold, a rush of warm air washes over you. You hear the sound of rushing water\r"
							+ "and see a shimmering pool in the distance. You feel a sense of calm as you realize this may be a respite from the dangers of the maze.");
			break;
		case 3:
			System.out.println(
					"You grit your teeth and choose the third door, knowing that the path ahead will be the most difficult. As you push through the smoke and shadows, \r"
							+ "you hear the sounds of hissing gas and roaring flames. You feel a sense of determination as you realize the rewards at the end of this path may be the greatest of all.");
			this.entrance = 3;
			break;
		default:
			System.out.println("Error choice difficulty in class Game");
		}
		return difficulty;
	}
	

	
	/* ---------------------------------------------------------------------------
	/* ***************************** JOUER UN TOUR *******************************/
	
	/**
	 * Méthode principale pour résoudre le labyrinthe.
	 * Gère le déroulement du tour du joueur, y compris le mouvement, le combat et la récupération d'objets.
	 * @param _adventurer Le personnage du joueur.
	 * @param difficulty La difficulté du jeu.
	 * @param _currentRoom La salle actuelle du joueur.
	 */
	public void solveMaze(Man _adventurer, int difficulty, Room _currentRoom) {
		
			this.currentRoom = _currentRoom;
			// showAdventurer(adventurer, difficulty); //affiche la position de l'aventurier
			if (_adventurer == null) {
				this.adventurer = createCharacter();
			} else {
				this.adventurer = _adventurer; 
			}
			
			Equipement loot;
			Room[][] map = this.maze.getMaze();
			
			while (this.adventurer.getHP() > 0 && !this.maze.isEnded()) {
				showSolution(this.adventurer, difficulty);
				adventurer.showStats();
				showGrid(adventurer, difficulty);
				// this.maze.showDoors();
				
				/* **************************** PHASE DE MOUVEMENT ****************************/
				/* ---------------------------------------------------------------------------- */
	
				chooseDirection(this.currentRoom, this.adventurer); // après cette étape, l'aventurier a pu se déplacer
				int x = this.adventurer.getPos().getX(), y = this.adventurer.getPos().getY();
	
				// ici on actualise simplement la salle actuelle de la map pour suivre
				// l'aventurier
				this.currentRoom = map[x][y];
				if (this.currentRoom.isBossRoom())
					this.maze.setEnded(true);
	
				
				/*
				 * ---------------------------------------------------------------------------
				 */
				/* ***************************** PHASE DE COMBAT ******************************/
	
				Monster monster = this.currentRoom.getMonster();
				if (!this.currentRoom.isVisited() && monster != null) {
					fight(this.adventurer, monster);
					// s'il n'y a pas d'ennemi dans la pièce
				} else {
					System.out.println(
							"It has been a considerable span of time since any enemies were last encountered.\n");
				}
	
				
				if (this.adventurer.isAlive() && !this.currentRoom.isVisited() && !this.currentRoom.isBossRoom()) {
					save(); // Sauvegarde de la partie
	
					loot = this.currentRoom.getEquipement();
					if (loot == null) {
						System.out.println("Sadly there is no more loots in this room\n");
					} else {
						choseLoot(this.adventurer, loot);
					}
					
					maze.addVisitedRoom(this.currentRoom);
					currentRoom.setVisited(true);
					currentRoom.setMonster(null);
					currentRoom.setEquipement(null);
			}
		}
	}

	/**
	 * Méthode de combat entre le joueur et un monstre.
	 * @param adventurer Le personnage du joueur.
	 * @param monster Le monstre à combattre.
	 */
	private void fight(Man adventurer, Monster monster) {
		String space = "		";
		boolean escape = false;
		System.out.println(
				space + "---------------------------------------------------------------------------");
		System.out.println(
				space + "***************************** PHASE DE COMBAT *****************************");
		System.out.println(space
				+ "---------------------------------------------------------------------------\n");

		adventurer.showStats();
		adventurer.showEquipment();
		System.out.println();

		System.out.println("You come face-to-face with the gargantuan " + monster.getName()
				+ ", ready to do battle.");
		while ((monster.isAlive() && adventurer.isAlive()) && !escape) {
			attack(adventurer, monster);
			if (monster.getHP() > 0 && adventurer.getHP() > 0) {
				//escape = adventurer.escape();
			}
			if (escape) {
				theEnd(adventurer, maze, 100000, true);
				System.exit(1);
			}
		}
		
	}


	/**
	 * Demande à l'utilisateur de saisir un entier 1 ou 2.
	 * Affiche un message d'erreur tant que l'entrée de l'utilisateur n'est pas valide.
	 * @return La valeur saisie par l'utilisateur (1 ou 2).
	 */
	public int get1or2() {
		int answer = 0;
		answer = keyboard.enterKeyboardInt();
		while (answer != 1 && answer != 2) {
			System.out.println("You have to write yes or no");
			answer = keyboard.enterKeyboardInt();
		}
		return answer;
	}
	
	
	/**
	 * Permet au joueur de choisir s'il souhaite récupérer un équipement trouvé.
	 * Affiche les informations sur l'équipement trouvé et demande à l'utilisateur de répondre "yes" ou "no".
	 * Si la réponse est "yes", l'équipement est équipé par le personnage.
	 * Si la réponse est "no", un message est affiché pour indiquer que l'équipement est laissé derrière.
	 * @param _adventurer Le personnage du joueur.
	 * @param _loot L'équipement trouvé.
	 */
	public void choseLoot(Man _adventurer, Equipement _loot) {
		_adventurer.showEquipment();
		_loot.found();
		System.out.println("Do you want to pick up " + _loot.getName() + " to replace your stuff ?");
		System.out.println("*   \u001B[1m1. yes\u001B[0m ");
		System.out.println("*   \u001B[1m2. no\u001B[0m ");
		if (get1or2() == 1)
			_adventurer.equipStuff(_loot);
		else
			System.out.println("You've decided to leave " + _loot.getName() + " behind you!");
	}

	
	/**
	 * Affiche les statistiques finales du jeu une fois celui-ci terminé.
	 * @param _adventurer Le personnage du joueur.
	 * @param _maze Le labyrinthe du jeu.
	 * @param _time Le temps écoulé pendant le jeu.
	 */
	private void theEnd(Man _adventurer, Maze _maze, long _time, boolean escape) {

		float result = ((float) _adventurer.getRoomExplored() / (float) _maze.getSize() * 100);
		int s = (((int) _time / 1000) % 60);
		int m = (((int) (_time / 1000) / 60) % 60);
		int h = (((int) (_time / 1000) / 60 / 60) % 24);
		String executionTime = String.format("%02d:%02d:%02d", h, m, s);

		System.out.println(
				"**********************************************************************************************");
		System.out.println(
				"******************************************* \u001B[1m\u001B[40mTHE END\u001B[47m\u001B[0m ******************************************");
		System.out.println(
				"**********************************************************************************************");
		System.out.print("###  YOU HAVE KILLED \u001B[31m\u001B[43m\u001B[1m" + _adventurer.getMonsterKilled()
				+ "\u001B[0m Monsters                                                            ###\n"
				+ "###  YOU HAVE EXPLORED \u001B[31m\u001B[43m\u001B[1m" + _adventurer.getRoomExplored()
				+ "\u001B[0m Rooms                                                             ###\n"
				+ "###  YOU HAVE COMPLETED \u001B[31m\u001B[43m\u001B[1m" + (int) result
				+ "%\u001B[0m of the maze                                                    ###\n"
				+ "###  YOU HAVE SURVIVED \u001B[31m\u001B[43m\u001B[1m" + executionTime
				+ "\u001B[0m in the maze                                                ###\n");
		System.out.println(
				"**********************************************************************************************");
		System.out.println(
				"Realised by \u001B[31m\u001B[43m\u001B[1mSAMAR\u001B[0m, \u001B[31m\u001B[43m\u001B[1mNERMINE\u001B[0m and \u001B[31m\u001B[43m\u001B[1mVALENTIN\u001B[0m\n\n");
		if (_adventurer.isAlive() && !escape)
			System.out.println(
					"\u001B[32mCongratulations, adventurer!\u001B[0m\nYour \u001B[1mheroic deeds\u001B[0m have proven your \u001B[4mworth\u001B[0m in this realm. But the \u001B[1mchallenges never truly end\u001B[0m, so take heart and \u001B[3mcontinue your journey\u001B[0m with even greater \u001B[31mvalor\u001B[0m.\nMore \u001B[1mtrials\u001B[0m await the \u001B[1mbrave\u001B[0m, and the rewards of \u001B[4mvictory grow ever greater\u001B[0m.\nWill you \u001B[1mrise to the challenge once more\u001B[0m?");
		else
			System.out.println(
					"Although your journey has ended in \u001B[31mdefeat\u001B[0m, do not \u001B[2mdespair\u001B[0m, brave adventurer.\nThe path to \u001B[4mvictory\u001B[0m is fraught with \u001B[1mchallenge\u001B[0m, and the most \u001B[4mvaliant of heroes\u001B[0m have tasted bitter \u001B[31mdefeat\u001B[0m before claiming \u001B[4multimate triumph\u001B[0m.\nTake heart, and let this experience be a \u001B[2mlesson\u001B[0m that will aid you on your \u001B[1mnext quest\u001B[0m.\nThe \u001B[1mchallenges of this realm remain\u001B[0m, and with \u001B[3mrenewed vigor\u001B[0m, you may yet emerge \u001B[4mvictorious\u001B[0m.\nWill you \u001B[1mrise to the challenge once more\u001B[0m?");
	}

	/**
	 * Sauvegarde la partie du jeu.
	 */
	public void save() {
		
		String space = "			";
		String line = space + "***********************************************************************";
		System.out.println(line);
		System.out.println(space +"* Do you want to save ?                                               *");
		System.out.println(space +"*   \u001B[1m1. yes\u001B[0m 						               *");
		System.out.println(space +"*   \u001B[1m2. no\u001B[0m 						               *");
		System.out.println(line);
		System.out.println();
		
		int answerS = get1or2();
		if (answerS == 1) {
			SaveGame.saveGame(this, "save.dat");
		}
		
		System.out.println(line);
		System.out.println(space +"* Do you want to continue ?                                                *");
		System.out.println(space +"*   \u001B[1m1. yes\u001B[0m 						            *");
		System.out.println(space +"*   \u001B[1m2. no\u001B[0m 						                 *");
		System.out.println(line);
		System.out.println();
		answerS = get1or2();
		if (answerS == 2) {
			System.exit(1);
		}
	}
	
	/**
	 * Méthode pour effectuer une attaque entre le joueur et un monstre.
	 * @param _adventurer Le personnage du joueur.
	 * @param _monster Le monstre à attaquer.
	 */
	public void attack(Man _adventurer, Monster _monster) {
		int coinflip = 0, damage = 1;
		Weapon weapon = _adventurer.getWeapon();
		Random rand = new Random();
		coinflip = rand.nextInt(2);

		// si c'est pile l'aventurier attaque
		if (coinflip == 0) {
			if (_adventurer.isEquipedW()) {
				weapon.use();
				damage += weapon.getDamage();
				// _adventurer.attack(_monster);
			}
			_monster.takeDamage(damage);
			// si c'est face le monstre attaque
		} else {
			_adventurer.takeDamage(damage);
		}
		if (_monster.getHP() > 0 && _adventurer.getHP() <= 0) {
			System.out.println(_monster.getName() + " Won the fight");

		} else if (_monster.getHP() <= 0 && _adventurer.getHP() > 0) {
			_adventurer.winner();
		}
	}

	/**
	 * Méthode pour choisir une direction de déplacement.
	 * @param _currentRoom La salle actuelle du joueur.
	 * @param _adventurer Le personnage du joueur.
	 * @return La direction choisie.
	 */
	public String chooseDirection(Room _currentRoom, Man _adventurer) {
		boolean validRoom = true;
		String direction = "";

		while (validRoom) {
			direction = _adventurer.move();
			// validRoom = verifyPath(_currentRoom, direction, _adventurer);
			if (_currentRoom.isDoorClosed(direction) == false && verifyPath(direction, _adventurer)) {
				_adventurer.openDoor(_currentRoom, direction);
				validRoom = false;
			} else {
				System.out.println(
						"\u001B[1;34mThe \u001B[0mmassive\u001B[1;34m doors stood resolute,\ntheir \u001B[1;30miron bars\u001B[0m\u001B[1;34m tightly interlocked,\nbarring any passage through.\u001B[0m");

			}
		}
		return direction;
	}

	
	/**
	 * Affiche la grille du labyrinthe avec la position du joueur.
	 * @param _adventurer Le personnage du joueur.
	 * @param _difficulty La difficulté du jeu.
	 */
	public void showGrid(Man _adventurer, int _difficulty) {
		String space = "						";
		Room[][] map = this.maze.getMaze();
		for (int i = 0; i < this.maze.getRow(); i++) {
			System.out.print(space);
			for (int j = 0; j < this.maze.getRow(); j++) {
				System.out.print("+------+");
			}
			System.out.println();
			System.out.print(space);
			for (int j = 0; j < this.maze.getColumn(); j++) {
				Room r = map[i][j];
				// ici on vérifie si l'utilisateur est sur la case que l'on doit afficher
				if (_adventurer.getPos().equals(r.getPos())) {
					// si son pseudo a une taille > 4
					if (_adventurer.getName().length() >= 4)
						System.out.print("| " + _adventurer.getName().substring(0, 4) + " |");
					else
						System.out.print("| " + _adventurer.getName() + "  |");
				} else {
					if (r.getId() < 10)
						System.out.print("|  " + r.getId() + "   |");
					else
						System.out.print("|  " + r.getId() + "  |");
				}
			}
			System.out.println();
		}
		if (_difficulty == 1) {
			System.out.println(space + "+----------------------+\n");
		} else if (_difficulty == 2) {
			System.out.println(space + "+--------------------------------------+\n");
		} else {
			System.out.println(space + "+------------------------------------------------------+\n");
		}

	}
	
	/**
	 * Affiche la solution du labyrinthe avec la position du joueur.
	 * Les portes fermées sont affichées en rouge et les portes ouvertes en vert.
	 * Le nom du joueur est affiché sur sa position actuelle.
	 * @param _adventurer Le personnage du joueur.
	 * @param _difficulty La difficulté du labyrinthe.
	 */
	public void showSolution(Man _adventurer, int _difficulty) {
		String space = "						";
		String pipeR = "\u001B[31m|\u001B[0m", pipeV = "\u001B[32m|\u001B[0m";
		String westDoor = "", eastDoor = "";
		Room[][] map = this.maze.getMaze();
		for (int i = 0; i < this.maze.getRow(); i++) {
			System.out.print(space);
			for (int j = 0; j < this.maze.getRow(); j++) {
				if (map[i][j].isDoorClosed("N") && !map[i][j].isEntrance())
					System.out.print("\u001B[31m+------+\u001B[0m");
				else
					System.out.print("\u001B[32m+------+\u001B[0m");
			}
			System.out.println();
			System.out.print(space);

			for (int j = 0; j < this.maze.getColumn(); j++) {
				Room r = map[i][j];
				// ici on vérifie si l'utilisateur est sur la case que l'on doit afficher

				if (r.isDoorClosed("W"))
					westDoor = pipeR;
				else
					westDoor = pipeV;

				if (r.isDoorClosed("E"))
					eastDoor = pipeR;
				else
					eastDoor = pipeV;

				if (_adventurer.getPos().equals(r.getPos())) {
					// si son pseudo a une taille > 4
					if (_adventurer.getName().length() >= 4)
						System.out.print(westDoor + " " + _adventurer.getName().substring(0, 4) + " " + eastDoor);
					else
						System.out.print(westDoor + " " + _adventurer.getName() + "  " + eastDoor);
				} else {
					if (r.getId() < 10)
						System.out.print(westDoor + "  " + r.getId() + "   " + eastDoor);
					else
						System.out.print(westDoor + "  " + r.getId() + "  " + eastDoor);
				}
			}
			System.out.println();
		}
		System.out.print(space);
		for (int j = 0; j < this.maze.getRow(); j++) {
			if (map[this.maze.getRow() - 1][j].isBossRoom())
				System.out.print("\u001B[32m+------+\u001B[0m");
			else
				System.out.print("\u001B[31m+------+\u001B[0m");
		}
		System.out.println();
	}
	
	
	/**
	 * Affiche le message de bienvenue du jeu.
	 */
	public void welcomeMessage() {

		String space = "	";
		String line = space + "***************************************************************************************************";
		System.out.println(line);
		System.out.println(space + "*  \u001B[33m##   ##  #######    ####   ######    #####        ##   ##   ######   #####    ##  ##   # #####\u001B[0m *");
		System.out.println(space + "*  \u001B[32m###  ##   ##   #   ##  ##   ##  ##  ### ###       ###  ##     ##    ##   ##   ##  ##  ## ## ## *");
		System.out.println( space +"*  #### ##   ##      ##        ##  ##  ##   ##       #### ##     ##    ##        ##  ##     ##    *");
		System.out.println( space +"*  #######   ####    ##        #####   ##   ##       #######     ##    ## ####   ######     ##    *");
		System.out.println(space + "*  ## ####   ##      ##        ## ##   ##   ##       ## ####     ##    ##   ##   ##  ##     ##    *");
		System.out.println( space +"*  ##  ###   ##   #   ##  ##   ## ##   ### ###       ##  ###     ##    ##   ##   ##  ##     ##\u001B[0m    *");
		System.out.println(space + "*  \u001B[33m##   ##  #######    ####   #### ##   #####        ##   ##   ######   #####    ##  ##    ####\u001B[0m   *");;
		
		System.out.println(line);
		System.out.println();

	}

	
	/**
	 * Affiche les choix de jeu (Adventurer ou DungeonMaster) et demande à l'utilisateur de choisir.
	 * @return La valeur choisie par l'utilisateur (1 pour Adventurer, 2 pour DungeonMaster).
	 */
	public int displayChoices() {
		String space = "			";
		String line = space + "***********************************************************************";
		System.out.println(line);
		System.out.println(space +"* What do you want to play ?                                          *");
		System.out.println(space +"*   \u001B[1m1. Adventurer\u001B[0m 						      *");
		System.out.println(space +"*   \u001B[1m2. DungeonMaster\u001B[0m 						      *");
		System.out.println(line);
		System.out.println();
		return get1or2();
	}

	public boolean isNewGame() {
		return isNewGame;
	}



	public void setNewGame(boolean isNewGame) {
		this.isNewGame = isNewGame;
	}



	/**
	 * Affiche les choix du menu de l'Adventurer et demande à l'utilisateur de choisir.
	 * @return La valeur choisie par l'utilisateur (1 pour Nouvelle partie, 2 pour Charger une partie).
	 */
	public int displayAdventurerChoices() {
		String space = "			";
		String line = space + "***********************************************************************";
		System.out.println(line);
		System.out.println(space +"* Menu           			                              *");
		System.out.println(space +"*   \u001B[1m1. New Game\u001B[0m 						      *");
		System.out.println(space +"*   \u001B[1m2. Load Game\u001B[0m 						      *");
		System.out.println(line);
		System.out.println();
		return get1or2();
	}

	/**
	 * Affiche les choix du menu du DungeonMaster et demande à l'utilisateur de choisir.
	 * @return La valeur choisie par l'utilisateur (entre 1 et 8 inclus).
	 */
	public int displayDungeonMasterChoices() {
		String space = "			";
		String line = space + "***********************************************************************";
		System.out.println(line);
		System.out.println(space +"* Welcome dungeon master, what do you want to do today ?              *");
		System.out.println(space +"*   \u001B[1m1. Add monster\u001B[0m 						      *");
		System.out.println(space +"*   \u001B[1m2. Remove monster\u001B[0m 						      *");
		System.out.println(space +"*   \u001B[1m3. Add door\u001B[0m 						      *");
		System.out.println(space +"*   \u001B[1m4. Remove door\u001B[0m 						      *");
		System.out.println(space +"*   \u001B[1m5. Add loot\u001B[0m 						      *");
		System.out.println(space +"*   \u001B[1m6. Remove loot\u001B[0m 						      *");
		System.out.println(space +"*   \u001B[1m7. Add room\u001B[0m 						      *");
		System.out.println(space +"*   \u001B[1m8. Remove room\u001B[0m 						      *");
		System.out.println(line);
		System.out.println();
		int choice = keyboard.enterKeyboardInt();
		while (choice < 1 || choice > 8) {
			System.out.println("value out of bound");
			choice = keyboard.enterKeyboardInt();
		}
		return choice;
	}
	
	public Room getCurrentRoom() {
		return currentRoom;
	}



	public Man getAdventurer() {
		return adventurer;
	}



	public int getDifficulty() {
		return difficulty;
	}
	 
	/**
	 * Vérifie si le déplacement dans une direction donnée est possible pour le joueur.
	 * @param direction La direction du déplacement (N, E, S, W).
	 * @param _adventurer Le personnage du joueur.
	 * @return true si le déplacement est possible, false sinon.
	 */
	public boolean verifyPath(String direction, Man _adventurer) {
		int x = _adventurer.getPos().getX(), y = _adventurer.getPos().getY();
		switch (direction) {
		case "N":
			x--;
			break;
		case "E":
			y += 1;
			break;
		case "S":
			x++;
			break;
		case "W":
			y--;
			break;
		}
		// on vérifie que le déplacement ne mène pas à une case en dehors de lu
		// labyrinthe
		if (x < 0 || y < 0 || x > (this.maze.getRow() - 1) || y > (this.maze.getColumn()) - 1) {
			System.out.println(
					"The way is blocked");
			return false;
		}
		return true;

	}

	public void setDifficulty(int difficulty) {
		this.difficulty = difficulty;
	}
	
}
