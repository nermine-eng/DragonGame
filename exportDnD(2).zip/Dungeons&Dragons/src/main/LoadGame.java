package main;

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
/**
 * La classe LoadGame permet de charger une partie de jeu à partir d'un fichier.
 * Elle fournit une méthode statique pour charger la partie à partir du fichier spécifié.
 */
public class LoadGame {
    public static Game loadGame(String filename) {
        try {
            FileInputStream fileIn = new FileInputStream(filename);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            Game game = (Game) in.readObject();
            in.close();
            fileIn.close();
            System.out.println("Game loaded successfully!");
            return game;
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filename);
        } catch (IOException e) {
            System.out.println("Error while reading the file: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Error while loading the game: Class not found");
        }
        
        return null;
    }
}