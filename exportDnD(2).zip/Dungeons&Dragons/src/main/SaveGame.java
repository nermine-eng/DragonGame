package main;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * La classe SaveGame permet de sauvegarder une partie de jeu dans un fichier.
 * Elle fournit une méthode statique pour sauvegarder la partie spécifiée dans le fichier spécifié.
 */
public class SaveGame implements Serializable {
	
    private static final long serialVersionUID = 1L;

    public static void saveGame(Game game, String filename) {
        try {
            FileOutputStream fileOut = new FileOutputStream(filename);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(game);
            out.close();
            fileOut.close();
            System.out.println("Game saved successfully!");
        } catch (Exception e) {
            System.out.println("Error while saving the game: " + e.getMessage());
            e.printStackTrace(); // Ajout pour aider au débogage
        }
    }
}
