package view;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Classe utilitaire pour la saisie au clavier.
 */
public class keyboard {

	
	private static Scanner scanner = new Scanner(System.in); 

	/**
     * Permet de saisir un entier à partir du clavier.
     * @return L'entier saisi.
     */
	public static int enterKeyboardInt() {
		boolean validInput = false;
		int num = 0;
		while (!validInput)
			try {
				num = scanner.nextInt();
				validInput = true;
			} catch (InputMismatchException e) {
				System.out.println("Error : Please enter a number");
				scanner.nextLine();
			}
		return num;
	}
	
	/**
     * Permet de saisir une chaîne de caractères à partir du clavier.
     * @return La chaîne de caractères saisie.
     */
	public static String enterKeyboardString() {
		String str = "";
		boolean validInput = false;
		while (!validInput) {
		    if (scanner.hasNextInt()) { 
		        System.out.println("Error : Please enter a String");
		        scanner.nextLine(); // consommer la ligne erronée
		    } else {
		        str = scanner.nextLine();
		        validInput = true;
		    }
		}
		return str;
	}

	
}
