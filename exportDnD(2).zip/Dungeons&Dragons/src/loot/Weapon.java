package loot;

import java.io.Serializable;

/**
 * Classe représentant une arme dans le jeu.
 * Elle étend la classe abstraite Equipement et implémente Serializable.
 */
public class Weapon extends Equipement implements Serializable{

	
	private static final long serialVersionUID = -2340076710955205356L;
	private int durability, damage;
	
	
	/**
     * Constructeur de la classe Weapon.
     * @param _name Le nom de l'arme.
     * @param _damage Les dégâts de l'arme.
     * @param _durability La durabilité de l'arme.
     */
	public Weapon(String _name, int _damage, int _durability) {
		super(_name, _damage, TypeEquipment.WEAPON);
		this.durability = _durability;
		this.damage = _damage;
	}
	
	
	public int getDamage() {
		return damage;
	}


	public int getDurability() {
		return durability;
	}

	public void setDurability(int durability) {
		this.durability = durability;
	}
	
	public boolean isDestroyed() {
		return (this.durability == 0);
	}
	
	public void destroy() {
		System.out.println("My faithful sword \u001B[91mshattered\u001B[0m upon the relentless assault of my foe, leaving me \u001B[91mdefenseless\u001B[0m and \u001B[91munprepared\u001B[0m for further conflict.");
		this.getOwner().setWeapon(null);
		this.getOwner().setEquipedW(false);
	}
	
	public void use() {
		System.out.println("You use " + this.getColoredName() + ".");
		this.durability--;
		// si la durabilité de l'arme tombe à 0
		if (isDestroyed()) {
			this.destroy();
		}
	}
	
	public void found() {
		super.found();
		System.out.println("and " + this.durability + " durability.");
	}

	
}
