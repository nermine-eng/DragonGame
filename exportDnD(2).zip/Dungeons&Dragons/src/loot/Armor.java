package loot;

import java.io.Serializable;

/**
 * Classe représentant une armure dans le jeu.
 * Elle étend la classe Equipement et implémente Serializable.
 */
public class Armor extends Equipement implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6241989582828606694L;
	private int state;
	
	
	/**
     * Constructeur de la classe Armor.
     * @param _name Le nom de l'armure.
     * @param _bonus Le bonus de l'armure.
     */
	public Armor(String _name, int _bonus) {
		super(_name, _bonus, TypeEquipment.ARMOR);
		this.state = _bonus;
	}
	
	  /**
     * Affiche un message indiquant que l'armure a été trouvée.
     */
	public void found() {
		super.found();
		System.out.println("and can block " + this.state + " more damages.");
	}
	
	 /**
     * Utilise l'armure en réduisant son état.
     */
	public void use() {
		System.out.println("You use " + this.getName() + ".");
		this.state--;
		// si la durabilité de l'armure tombe à 0
		if (isDestroyed()) {
			this.destroy();
		}
	}
	
	/**
     * Détruit l'armure et affiche un message indiquant que l'armure est détruite.
     */
	public void destroy() {
		System.out.println("Your armor \u001B[91mshattered\u001B[0m upon the devastating blow of my enemy's strike, \u001B[91mleaving\u001B[0m you \u001B[91mvulnerable\u001B[0m and exposed to further attacks.");
		this.getOwner().setWeapon(null);
		this.getOwner().setEquipedW(false);
	}
	
	/**
     * Vérifie si l'armure est détruite.
     * @return true si l'armure est détruite, false sinon.
     */
	public boolean isDestroyed() {
		return this.state == 0;
	}
	
}
