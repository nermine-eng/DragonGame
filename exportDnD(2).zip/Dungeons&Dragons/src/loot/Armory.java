package loot;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/**
 * Classe abstraite représentant l'armurerie du jeu.
 * Elle implémente Serializable.
 */
public abstract class Armory implements Serializable {

	
	private static final long serialVersionUID = -4540942409016893524L;
	private static final List<Weapon> Weapons = new ArrayList<>();
	private static final List<Armor> Armors = new ArrayList<>();

    static {
    	Weapons.add(new Weapon("Rusty Dagger", 1, 3));
    	Weapons.add(new Weapon("Wooden Club", 2, 2));
    	Weapons.add(new Weapon("Iron Shortsword", 3, 4));
    	Weapons.add(new Weapon("Steel Longsword", 4, 6));
    	Weapons.add(new Weapon("Golden Scimitar", 5, 8));
    	Weapons.add(new Weapon("Dragon Slayer", 5, 10));
    	Weapons.add(new Weapon("Demonbane", 4, 9));
    	Weapons.add(new Weapon("Thunder Hammer", 3, 8));
    	Weapons.add(new Weapon("Shadow Blade", 2, 6));
    	Weapons.add(new Weapon("Soul Stealer", 1, 5));
    	Weapons.add(new Weapon("Sword of Flames", 4, 7));
        Weapons.add(new Weapon("Spear of Ice", 4, 7));
        Weapons.add(new Weapon("Mace of the Titans", 5, 9));
        Weapons.add(new Weapon("Warhammer of Doom", 5, 10));
        Weapons.add(new Weapon("Axe of the Executioner", 3, 8));
    }
    
    static {
        Armors.add(new Armor("Leather Gloves", 1));
        Armors.add(new Armor("Chainmail Shirt", 2));
        Armors.add(new Armor("Scale Armor", 3));
        Armors.add(new Armor("Plate Armor", 4));
        Armors.add(new Armor("Dragonhide Vest", 5));
        Armors.add(new Armor("Demonplate Armor", 5));
        Armors.add(new Armor("Thunder Shield", 4));
        Armors.add(new Armor("Shadow Cloak", 3));
        Armors.add(new Armor("Soul Amulet", 2));
        Armors.add(new Armor("Helm of the Titan", 4));
        Armors.add(new Armor("Fireproof Gauntlets", 3));
        Armors.add(new Armor("Ice-resistant Boots", 3));
        Armors.add(new Armor("Mithril Breastplate", 5));
        Armors.add(new Armor("Adamantine Plate", 5));
        Armors.add(new Armor("Rusted Plate", 1));
    }

    
    /**
     * Sélectionne une arme en fonction du niveau de progression du joueur.
     * @param _stage Le niveau de progression du joueur.
     * @return L'arme sélectionnée.
     */
    public static Weapon selectWeapon(int _stage) {
    	//on cherche une arme adapté au niveau de progression du joueur
    	for (Weapon w : Weapons) {
    		if (w.getBonus() == _stage)
    			Weapons.remove(w);
    			return w;
    	}
    	return null;
    }
    
    /**
     * Sélectionne une armure en fonction du niveau de progression du joueur.
     * @param _stage Le niveau de progression du joueur.
     * @return L'armure sélectionnée.
     */
    public static Armor selectArmor(int _stage) {
    	//on cherche une armure adapté au niveau de progression du joueur
    	for (Armor w : Armors) {
    		if (w.getBonus() == _stage)
    			Armors.remove(w);
    			return w;
    	}
    	return null;
    }
    
    
	public static List<Weapon> getWeapons() {
		return Weapons;
	}
	

	public static List<Armor> getArmors() {
		return Armors;
	}
    
    
}
