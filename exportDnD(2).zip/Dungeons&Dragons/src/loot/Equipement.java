package loot;

import java.io.Serializable;
//import java.util.Random;

import characters.Man;

/**
 * Classe abstraite représentant un équipement du jeu.
 * Elle implémente Serializable.
 */
public abstract class Equipement implements Serializable {

	private static final long serialVersionUID = 7225949259012012623L;
	private final String name, description;
	private final int bonus; //from 1 to 5
	private final TypeEquipment type;
	private Man owner;
	
	
	 /**
     * Constructeur de la classe Equipement.
     * @param _name Le nom de l'équipement.
     * @param _bonus Le bonus de l'équipement.
     * @param _type Le type d'équipement.
     */
	public Equipement(String _name, int _bonus, TypeEquipment _type) {
		this.name = _name;
		this.bonus = _bonus;
		this.description = _name + " - " + genererDescriptionArme(_name, _bonus);
		this.type = _type;
	}
	
	
	/**
     * Retourne le type d'équipement.
     * @return Le type d'équipement.
     */
	public TypeEquipment getType() {
		return type;
	}

	public String getName() {
		return name;
	}
	
	public String getColoredName() {
		return "\u001B[33m" + name + "\u001B[0m";
	}
	
	
	public int getBonus() {
		return bonus;
	}
	
	public abstract void use();
	
	public abstract boolean isDestroyed();
	
	/**
     * Génère une description pour l'équipement en fonction de son nom et de son bonus.
     * @param _name Le nom de l'équipement.
     * @param _bonus Le bonus de l'équipement.
     * @return La description générée.
     */
	public static String genererDescriptionArme(String _name, int _bonus) {
	    if (_bonus >= 4) {
	        return "\u001B[33m" + _name + "\u001B[0m" + " is a formidable Equipement that strikes fear into the hearts of your enemies.";
	    } else if (_bonus >= 3 ) {
	        return _name + " is a reliable Equipement that will serve you well in any battle.";
	    } else if (_bonus >= 2) {
	        return _name + " is a decent Equipement, but you should handle it with care.";
	    } else {
	        return _name + " is a weak Equipement that might not even last through a single fight.";
	    }
	}
	
	/**
     * Affiche un message indiquant que l'équipement a été trouvé.
     */
	public void found() {
		System.out.println("You have found the \u001B[33m" + this.name + "\u001B[0m\n" + this.description);
		System.out.print("This weapon has " + this.bonus + " bonus ");
	}

	public Man getOwner() {
		return owner;
	}

	public void setOwner(Man owner) {
		this.owner = owner;
	}

	
}
