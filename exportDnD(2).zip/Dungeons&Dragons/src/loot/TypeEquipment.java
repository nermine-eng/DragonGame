package loot;

public enum TypeEquipment {
	WEAPON, ARMOR
}
