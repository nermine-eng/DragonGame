package map;

import java.io.Serializable;

/**
 * Classe représentant une position dans la carte du jeu.
 * Elle implémente Serializable.
 */
public class Position implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8533081916762966190L;
	private int x, y;

	
	/**
     * Constructeur de la classe Position.
     * @param _x La coordonnée x de la position.
     * @param _y La coordonnée y de la position.
     */
	public Position(int _x, int _y) {
		this.x = _x;
		this.y = _y;
	}


	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}


	public void setX(int x) {
		this.x = x;
	}


	public void setY(int y) {
		this.y = y;
	}


	@Override
	public String toString() {
		return "Position x=" + x + ", y=" + y;
	}

	@Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Position other = (Position) obj;
        if (this.x != other.x) {
            return false;
        }
        if (this.y != other.y) {
            return false;
        }
        return true;
    }
}
