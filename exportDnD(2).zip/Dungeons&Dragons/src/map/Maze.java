package map;

import java.util.List;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Random;
import java.util.HashSet;


/**
 * Classe représentant un labyrinthe dans le jeu.
 * Elle implémente Serializable.
 */
public class Maze implements Serializable{

	private static final long serialVersionUID = -5675808040159345133L;
	private List<Room> rooms;
	private List<Integer> exploredRooms;
	
	private int difficulty;
	private int row, column, size;
	private Room[][] maze;
	private boolean isEnded = false;
	private Room entrance, exit;
	

	/**
     * Constructeur de la classe Maze.
     * @param _difficulty La difficulté du labyrinthe.
     */
	public Maze(int _difficulty) {
		this.exploredRooms  = new ArrayList<>();
		this.rooms = new LinkedList<>();
		this.difficulty = _difficulty;
		this.size = setSize();
		this.maze = new Room[row][column];
		//initializeMaze();
		initializeMazeGrid();
		generateMazeGrid();
		//showMaze();
	}
	
	
	/**
     * Initialise la grille du labyrinthe avec des salles vides.
     */
	public void initializeMazeGrid() {
		Random rand = new Random();
		for (int i = 0; i < this.row; i++) {
			for (int j = 0; j < this.column; j++) {
				// la dernière room est une bossRoom
				this.maze[i][j] = new Room(i, j);
			}
		}
		this.entrance = setEntrance();
		this.exit = maze[row - 1][rand.nextInt(column)];
		this.exit.setEquipement(null);// pas de loot dans la salle du boss car le labyrinthe est finit
		this.exit.setBossRoom(true);
	}
	
	 /**
     * Affiche l'état des portes dans chaque salle du labyrinthe.
     * Fonction de debbugage
     */
	public void showDoors() {
		for (int i = 0; i < this.row; i++) {
			for (int j = 0; j < this.column; j++) {
				// la dernière room est une bossRoom
				for (Door d : this.maze[i][j].getDoors()) {
					System.out.println("Room " + i + " - " + j +"Porte " + d.getDirection() + " est fermé -> " + d.isClosed());
					System.out.println();
				}
			}
		}
	}
	
	
	  /**
     * Génère le labyrinthe en utilisant l'algorithme de génération de labyrinthe aléatoire.
     */
	public void generateMazeGrid() {
		HashSet<Room> inMaze = new HashSet<>();
        List<Room> frontier = new ArrayList<>();
        Random rand = new Random();

        inMaze.add(entrance);

        frontier.addAll(getNeighbors(entrance));

        while (!frontier.isEmpty()) {
            Room room = frontier.remove(rand.nextInt(frontier.size()));

            List<Room> inMazeNeighbors = getNeighbors(room);
            inMazeNeighbors.retainAll(inMaze);

            if (!inMazeNeighbors.isEmpty()) {
                Room neighbor = inMazeNeighbors.get(rand.nextInt(inMazeNeighbors.size()));
                connectRooms(room, neighbor);

                inMaze.add(room);

                List<Room> neighbors = getNeighbors(room);
                for (Room neighborRoom : neighbors) {
                    if (!inMaze.contains(neighborRoom) && !frontier.contains(neighborRoom)) {
                        frontier.add(neighborRoom);
                    }
                }
            }
        }
    }
	
	
	/**
     * Ouvre une porte dans une salle donnée dans une direction donnée.
     * @param _room La salle dans laquelle ouvrir la porte.
     * @param direction La direction de la porte à ouvrir.
     */
	public void openDoor(Room _room, String direction) {
		for (Door d : _room.doors) {
			if (d.getDirection().equals(direction)) {
				d.setClosed(false);
			}
		}
	}
	
	
	 /**
     * Connecte deux salles en ouvrant les portes correspondantes.
     * @param _room La première salle à connecter.
     * @param _neighbor La seconde salle à connecter.
     */
	private void connectRooms(Room _room, Room _neighbor) {
	    int xR = _room.getX(), yR = _room.getY(), xN = _neighbor.getX(), yN = _neighbor.getY();
	    if (xR == xN) {
	  
	        if (yR > yN) {
	            openDoor(_room, "W");
	            openDoor(_neighbor, "E");
	        } else {
	            openDoor(_room, "E");
	            openDoor(_neighbor, "W");
	        }
	        //System.out.println("Abscisse -> xR yR xN yN = " + xR + yR + xN + yN + _room.getDoors().toString() + "\n" + _neighbor.getDoors().toString());
	    } else {
	        if (xR > xN) {
	            openDoor(_room, "N");
	            openDoor(_neighbor, "S");
	        } else {
	            openDoor(_room, "S");
	            openDoor(_neighbor, "N");
	        }
	    }
	}


	/**
     * Récupère les voisins d'une salle donnée dans le labyrinthe.
     * @param _room La salle pour laquelle récupérer les voisins.
     * @return La liste des voisins de la salle.
     */
	private List<Room> getNeighbors(Room _room) {
	    List<Room> neighbors = new ArrayList<>();

	    int x = _room.getX();
	    int y = _room.getY();

	    if (x > 0) 
	    	neighbors.add(maze[x - 1][y]);
	    if (x < row - 1) 
	    	neighbors.add(maze[x + 1][y]);
	    if (y > 0) 
	    	neighbors.add(maze[x][y - 1]);
	    if (y < column - 1) 
	    	neighbors.add(maze[x][y + 1]);
	    return neighbors;
	}
	
    /**
     * Définit l'entrée du labyrinthe en fonction de la difficulté.
     * @return La salle d'entrée du labyrinthe.
     */
	public Room setEntrance() {
		switch (this.difficulty) {
			case 1 :
				maze[0][1].setEntrance(true);
				maze[0][1].setMonster(null);
				maze[0][1].setEquipement(null);
				return maze[0][2];
			case 2 :
				maze[0][2].setEntrance(true);
				maze[0][2].setMonster(null);
				maze[0][2].setEquipement(null);
				return maze[0][3];
			case 3 :
				maze[0][3].setEntrance(true);
				maze[0][3].setMonster(null);
				maze[0][3].setEquipement(null);
				return maze[0][4];
			default :
				return null;
		}
	}

    /**
     * Ajoute une salle explorée à la liste des salles explorées.
     * @param _room La salle explorée à ajouter.
     */
	public void addVisitedRoom(Room _room) {
		this.exploredRooms.add(_room.getId());
	}
	
	
	  /**
     * Affiche le labyrinthe avec ses salles et les connexions entre elles.
     */
	public void showMaze() {
		
		for(int i = 0; i < this.row; i++)  {
			for (int x = 0; x < this.row; x++) {
				System.out.print("--------");	
			}
			System.out.println();
			for(int j = 0; j < this.row; j++)  {
				System.out.print("|  " + this.getMaze()[i][j].getId() + "  | ");
				if (this.getMaze()[i][j].getId() % this.column == 0) {
					System.out.println("\r-----------------");
				}
			}
		}
	}

	public int setSize() {
		switch(this.difficulty) {
		case 0: 
			this.row = 1;
			this.column = 1;
			break;
		case 1 :
			this.row = 3;
			this.column = 3;
			break;
		case 2 :
			this.row = 5;
			this.column = 5;
			break;
		case 3 : 
			this.row = 7;
			this.column = 7;
			break;
		default :
			System.out.println("Error function setSize in class Maze");
		}
		return (row * column);
	}
	
	public int getSize() {
		return size;
	}

	public void setEnded(boolean isEnded) {
		this.isEnded = isEnded;
	}

	public boolean isEnded() {
		return isEnded;
	}

	public List<Room> getRooms() {
		return rooms;
	}

	public int getdifficulty() {
		return difficulty;
	}

	public int getRow() {
		return row;
	}

	public int getColumn() {
		return column;
	}

	public Room[][] getMaze() {
		return maze;
	}

	public int getDifficulty() {
		return difficulty;
	}

	public Room getEntrance() {
		return entrance;
	}

	public Room getExit() {
		return exit;
	}

	@Override
	public String toString() {
		return "Maze [rooms=" + rooms + ", exploredRooms=" + exploredRooms + ", difficulty=" + difficulty + ", row="
				+ row + ", column=" + column + ", size=" + size + ", maze=" + Arrays.toString(maze) + ", isEnded="
				+ isEnded + ", entrance=" + entrance + ", exit=" + exit + "]";
	}
	
	
	
}
