package map;

import java.io.Serializable;

/**
 * Classe représentant une porte dans une salle du labyrinthe.
 * Elle implémente Serializable.
 */
public class Door implements Serializable{
	
	private static final long serialVersionUID = -5467489901714285920L;
	private String direction;
	private boolean isClosed;
	
	
	/**
     * Constructeur de la classe Door.
     * @param _direction La direction de la porte.
     */
	public Door(String _direction) {
		this.direction = _direction;
		this.isClosed = true;
	}
	
	
	/**
     * Retourne la direction de la porte.
     * @return La direction de la porte.
     */
	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public boolean isClosed() {
		return isClosed;
	}

	public void setClosed(boolean isClosed) {
		this.isClosed = isClosed;
	}

	@Override
	public String toString() {
		return (direction + " isClosed=" + isClosed + " | ");
	}
	
	

	
}
