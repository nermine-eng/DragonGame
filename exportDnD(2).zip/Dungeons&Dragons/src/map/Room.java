package map;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import map.Position;
import characters.Monster;
import loot.Equipement;
import loot.Armory;

/**
 * Classe représentant une salle dans le labyrinthe.
 * Elle implémente Serializable.
 */
public class Room implements Serializable{
	
	private static final long serialVersionUID = 8025772758769913594L;
	private static int counter = 0;
	private int id, stage;
	protected List<Door> doors;
	private Monster monster;
	private Position pos;
	private boolean isBossRoom = false, visited= false, isEntrance = false;

	private Equipement equipement;
	
	
	 /**
     * Constructeur de la classe Room.
     * @param _x La position X de la salle.
     * @param _y La position Y de la salle.
     */
	public Room(int _x, int _y) {
		counter++;
		this.id = counter;
		this.doors = new ArrayList<>();
		this.pos = new Position(_x, _y);
		this.stage = pos.getX() + 1;
		
		initializeDoors();
		this.equipement = generateLoot();
		this.monster = new Monster(this.getPos());
		//System.out.println(toString());
	}


	  /**
     * Initialise les portes de la salle.
     */
	public void initializeDoors() {
		doors.add(new Door("N"));
		doors.add(new Door("E"));
		doors.add(new Door("S"));
		doors.add(new Door("W"));
	}
	
	
	/**
     * Définit si la salle est l'entrée du labyrinthe.
     * @param isEntrance Indique si la salle est l'entrée du labyrinthe.
     */
	public void setEntrance(boolean isEntrance) {
		this.isEntrance = isEntrance;
	}
	

    /**
     * Vérifie si une porte dans une direction donnée est fermée.
     * @param _direction La direction de la porte à vérifier.
     * @return true si la porte est fermée, sinon false.
     */
	public boolean isDoorClosed(String _direction) {
		for (Door d : this.doors) {
			if (d.getDirection().equals(_direction)) {
				return d.isClosed();
			}
		}
		return false;
	}


	 /**
     * Génère un équipement (arme ou armure) pour la salle.
     * @return L'équipement généré.
     */
	public Equipement generateLoot() {
		Random rand = new Random();
		int choice = rand.nextInt(2);
		if (choice == 1) 
			return Armory.selectWeapon(this.stage);
		return Armory.selectArmor(this.stage);
	}
	
    /**
     * Vérifie si la salle a été visitée.
     * @return true si la salle a été visitée, sinon false.
     */
	public boolean isVisited() {
		return visited;
	}
	public int getId() {
		return id;
	}
	
	public void setVisited(boolean _visited) {
		this.visited = _visited;
	}
	
	@Override
	public String toString() {
		return "Room [id=" + id + ", doors=" + doors.toString() + ", posX = " + pos.getX() + ", posY = " + pos.getY() + ", isBossRoom=" + isBossRoom + "]";
	}

	public static int getCounter() {
		return counter;
	}

	public List<Door> getDoors() {
		return doors;
	}

	public Position getPos() {
		return pos;
	}
	
	public int getX() {
		return pos.getX();
	}

	public int getY() {
		return pos.getY();
	}
	
	public boolean isBossRoom() {
		return isBossRoom;
	}
	
	
	public void setMonster(Monster monster) {
		this.monster = monster;
	}

	public void setPos(Position pos) {
		this.pos = pos;
	}

	public void setPos(int _x, int _y) {
		this.pos.setX(_x);
		this.pos.setY(_y);
	}

	public Monster getMonster() {
		return monster;
	}
	
	public Equipement getEquipement() {
		return equipement;
	}

	public void setEquipement(Equipement equipement) {
		this.equipement = equipement;
	}

	public void setBossRoom(boolean isBossRoom) {
		this.isBossRoom = isBossRoom;
	}
	public boolean isEntrance() {
		return isEntrance;
	}

}
