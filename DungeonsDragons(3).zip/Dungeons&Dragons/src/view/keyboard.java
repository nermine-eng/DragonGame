package view;

import java.util.InputMismatchException;
import java.util.Scanner;


public class keyboard {

	private static Scanner scanner = new Scanner(System.in); 

	public static int enterKeyboardInt() {
		int num = 0;
		try {
			num = scanner.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("Erreur : Please enter a number");
			scanner.next();
		}
		return num;
	}

	public static String enterKeyboardString() {
		return scanner.next();
	}

}
