package map;

import java.util.ArrayList;
import java.util.List;

public class Room {
	
	private static int counter = 0;
	private int id;
	protected List<Door> doors;

	private Position pos;
	private boolean isBossRoom;
	
	
	public Room(int _x, int _y, boolean _isBossRoom) {
		counter++;
		this.id = counter;
		this.doors = new ArrayList<>();
		this.pos = new Position(_x, _y);
		initializeDoors();
		this.isBossRoom = _isBossRoom;
		//System.out.println(toString());
	}

	public void initializeDoors() {
		doors.add(new Door("N"));
		doors.add(new Door("E"));
		doors.add(new Door("S"));
		doors.add(new Door("W"));
	}

	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Room [id=" + id + ", doors=" + doors.toString() + ", posX = " + pos.getX() + ", posY = " + pos.getY() + ", isBossRoom=" + isBossRoom + "]";
	}

	public static int getCounter() {
		return counter;
	}

	public List<Door> getDoors() {
		return doors;
	}

	public Position getPos() {
		return pos;
	}

	public boolean isBossRoom() {
		return isBossRoom;
	}
	
	public void setPos(int _x, int _y) {
		this.pos.setX(_x);
		this.pos.setY(_y);
	}
	
}
