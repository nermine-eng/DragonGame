package map;

public class Door {
	
	private String direction;
	private boolean isClosed;
	
	public Door(String _direction) {
		this.direction = _direction;
		this.isClosed = true;
	}
	
	public void openDoor() {
		this.isClosed = false;
	}

	public void closeDoor() {
		this.isClosed = true;
	}
	
	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public boolean isClosed() {
		return isClosed;
	}

	public void setClosed(boolean isClosed) {
		this.isClosed = isClosed;
	}

	@Override
	public String toString() {
		System.out.println("Door [direction=" + direction + ", isClosed=" + isClosed + "]");
		return "";
	}
	
	

	
}
