package map;

import java.util.List;
import java.util.LinkedList;

public class Maze {

	private List<Room> rooms;
	private int difficulte;
	private int row, column;
	private boolean isEnded = false;


	public Maze(int _difficulte) {
		this.rooms = new LinkedList<>();
		this.difficulte = _difficulte;
		initializeMaze();
		showMaze();
	}

	public void initializeMaze() {
		setSize();
		for (int i = 0; i < this.row; i++) {
			for (int j = 0; j < this.column; j++) {
				if (i == this.row - 1 && j == this.column - 1) { 
					this.rooms.add(new Room(i, j, true));
				} else {
					// la dernière room est une bossRoom
					this.rooms.add(new Room(i, j, false));
				}
				//Room tmp = new Room(i, j, false);
			}
		}
	}

	public void showMaze() {
		System.out.println("-----------------");
		for(Room r : this.rooms) {
			System.out.print("| " + r.getId() + " | ");
			if (r.getId() % this.column == 0) {
				System.out.println("\r-----------------");
			}
		}
	}

	public void setSize() {
		switch(this.difficulte) {
		case 1 :
			this.row = 3;
			this.column = 3;
			break;
		case 2 :
			this.row = 5;
			this.column = 5;
			break;
		case 3 : 
			this.row = 7;
			this.column = 7;
			break;
		default :
			System.out.println("Error function setSize in class Maze");
		}
	}
	
	public void setEnded(boolean isEnded) {
		this.isEnded = isEnded;
	}

	public boolean isEnded() {
		return isEnded;
	}

	public List<Room> getRooms() {
		return rooms;
	}

	public int getDifficulte() {
		return difficulte;
	}

	public int getRow() {
		return row;
	}

	public int getColumn() {
		return column;
	}


	
}
