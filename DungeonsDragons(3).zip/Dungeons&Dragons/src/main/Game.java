package main;

import java.util.List;
import characters.Monstre; // Importer la classe Monstre du package characters


import characters.Man;
import map.Maze;
import map.Position;
import map.Room;
import view.keyboard;


public class Game {

	private Maze maze;


	public void play() {
		String direction;
		
		System.out.println("Greetings adventurer! You have found yourself in a treacherous maze. The path ahead is unclear \r"
				+ "and the walls seem to shift and change as you move. Once you step inside, there may be no turning back. \r"
				+ "A voice calls out to you, what's your name adventurer ?");
		String name = keyboard.enterKeyboardString();
		Man adventurer = new Man(10, name);
		Monstre monstre = new Monstre(name);
		// Créer une instance de Monstre avec un nom spécifié
		monstre.attaquer(adventurer); // Appeler la méthode attaquer() du monstre avec l'objet du personnage en tant qu'argument

		if (adventurer.getHP() <= 0) {
			adventurer.mourir(); // Appeler la méthode mourir() du personnage si les points de vie atteignent 0 ou moins
		}
		monstre.gagnerCombat(); // Appeler la méthode gagnerCombat() du monstre pour augmenter les points de vie après une victoire


		
		System.out.println("Before you loom three doors, each evoking its own unique and formidable presence. The first door \r"
                + "appears" +  " \u001B[32msolid and unremarkable\u001B[0m" +", giving off an air of \u001B[32msecurity\u001B[0m\r. "
                + "The second door \u001B[33memanates a faint but welcoming warmth\u001B[0m, accompanied by the gentle sound of \u001B[33mrushing water\u001B[0m \r"
                + "beyond its threshold\r. "
                + "However, the last door presents a \u001B[31mdaunting challenge\u001B[0m, shrouded as it is in billowing smoke and foreboding \r"
                + "shadows. Although it may be the \u001B[31mmost difficult\u001B[0m of the three to pass, it also promises the greatest rewards. \r"
                + " Which door will you select ? (1, 2 or 3)");
		int difficulty = keyboard.enterKeyboardInt();
		
		while (difficulty < 1 || difficulty > 3) {
			System.out.println("You only have 3 choices : 1, 2 or 3");
			difficulty = keyboard.enterKeyboardInt();
		}
		
		switch(difficulty) {
			case 1 :
				System.out.println("You push open the first door and step into a dimly lit room. The air is stale, and the walls are adorned with cobwebs.\r "
						+ "You feel a sense of relief as you realize the path ahead seems relatively safe, at least for now.");
				break;
			case 2 :
				System.out.println("You choose the second door, and as you cross the threshold, a rush of warm air washes over you. You hear the sound of rushing water\r"
						+ "and see a shimmering pool in the distance. You feel a sense of calm as you realize this may be a respite from the dangers of the maze.");
				break;
			case 3 :
				System.out.println("You grit your teeth and choose the third door, knowing that the path ahead will be the most difficult. As you push through the smoke and shadows, \r"
						+ "you hear the sounds of hissing gas and roaring flames. You feel a sense of determination as you realize the rewards at the end of this path may be the greatest of all.");
				break;
			default :
				System.out.println("Error choice difficulty in class Game");
		}
		
		this.maze = new Maze(difficulty);	
		
		System.out.println("The adventurer pushes open the door and steps tentatively into the first room, their eyes adjusting to the dim lighting. \r\nThe room is sparsely furnished, with only a small table and chair in the center. \r\nAs they take a few cautious steps forward, "
				+ "the door behind them shuts with a resounding thud, leaving them alone in the eerie silence of the maze.");
		Room currentRoom = this.maze.getRooms().get(1); //Au début on commence dans la première salle
		
		while (!this.maze.isEnded()) {
			showAdventurer(adventurer);
			System.out.println(adventurer.toString());
			chooseDirection(currentRoom, adventurer);
			currentRoom = findRoom(this.maze.getRooms(), adventurer.getPos());
			if (currentRoom.isBossRoom()) {
				this.maze.setEnded(true);
			}

		}
	}

	public String chooseDirection(Room _currentRoom, Man _adventurer) {
		int validRoom = 0;
		String direction = "";
		
		while (validRoom == 0) {
			direction = _adventurer.move();
			validRoom = verifyPath(_currentRoom, direction, _adventurer);
		}
		return direction;
	}
	
	public void showAdventurer(Man _adventurer) {
		System.out.println("-----------------");
		for(Room r : this.maze.getRooms()) {
			if (_adventurer.getPos().equals(r.getPos())) {
				System.out.print("| " + _adventurer.getName() + " | ");
			} else {
				System.out.print("| " + r.getId() + " | ");
			}
			if (r.getId() % this.maze.getColumn() == 0) {
				System.out.println("\r-----------------");
			}
		}
	}
	
	public int verifyPath(Room _currentRoom, String direction, Man _adventurer) {
		int x = _adventurer.getPos().getX(), y = _adventurer.getPos().getY();
		switch(direction) {
			case "N" :
				x--;
				break;
			case "E" :
				y+=1;
				break;
			case "S" :
				x++;
				break;
			case "W" :
				y--;
				break;
		}
		// on vérifie que le déplacement ne mène pas à une case en dehors de lu labyrinthe
		if (x < 0 || y < 0 || x > (this.maze.getRow() - 1)  || y > (this.maze.getColumn()) - 1) {
			System.out.println("As you approach the door, you realize that it is firmly sealed shut, with no visible means of opening it.\r"
					+ "It seems that this path is closed off to you for now.");
			return 0;
		}
		System.out.println("As you turn the ancient key in the lock, the heavy door creaks open with a resounding groan.");
		//System.out.println("avant setPos " + _adventurer.getPos().toString());
		_adventurer.setPos(x, y);
		//System.out.println("après setPos " + _adventurer.getPos().toString());
		return 1;
	}
	
	public Room findRoom(List<Room> _rooms, Position _pos) {
		for (Room r : _rooms) {
			if (r.getPos().equals(_pos)) {
				return r;
			}
		}
		System.out.println("No room has been found in findRoom");
		return null;
	}
	
	public int findDoor(String _direciton) {
		switch (_direciton) {
		case "N" :
			return 1;
		case "E" :
			return 2;
		case "S" :
			return 3;
		case "W" :
			return 4;
		}
		return 0;
	}
		
		
}
