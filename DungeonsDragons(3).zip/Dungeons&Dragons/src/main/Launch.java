package main;

public class Launch {

	public static void main(String[] args) {
		Game myGame = new Game();
		myGame.play();
	}

}
