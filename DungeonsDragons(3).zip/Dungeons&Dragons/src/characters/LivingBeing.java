package characters;

import map.Position;
import java.util.Random;

public abstract class LivingBeing {

	private int HP;
	private String name;
	protected Position pos;
	
	public LivingBeing(int _HP, String _name) {
		this.HP = _HP;
		this.name = _name;
	}
	
	public abstract void mourir();
	
	public int getHP() {
		return HP;
	}

	public String getName() {
		return name;
	}

	public Position getPos() {
		return pos;
	}

	public void setHP(int hP) {
		HP = hP;
	}

	public void setPos(int _x, int _y) {
		this.pos.setX(_x);
		this.pos.setY(_y);
	}
	
	 public void perdreVie() {
	        // Utiliser un générateur de nombres aléatoires pour déterminer la quantité de dégâts à infliger
	        Random random = new Random();
	        int degats = random.nextInt(10) + 1; // Choix aléatoire entre 1 et 10
	        this.HP -= degats;
	        if (this.HP <= 0) {
	            mourir(); // Appeler la méthode mourir() si les points de vie atteignent 0 ou moins
	        }
	    }

}
