package characters;

import map.Position;
import java.util.Random;
import view.keyboard;

public class Man extends LivingBeing{

	public Man(int _HP, String _name) {
		super(_HP, _name);
		this.pos = new Position(0, 0);
		System.out.println(toString());
		showStats();
	}
	
	public String parler(String message) {
		return this.getName() + " : " + message;
	}
	
	public void mourir() {
		System.out.println("The adventurer's journey has come to an end. \r\nThey fought valiantly against the dangers of the maze, "
				+ "\r\nbut alas, it proved too much for them. \r\nTheir memory will live on as a brave and daring explorer \r\nwho dared to take on the treacherous depths of the labyrinth.");
	}
	 public void perdreVie() {
	        // Appeler la méthode perdreVie() de la classe mère pour effectuer les dégâts de base
	        super.perdreVie();
	        
	        // Ajouter des dégâts supplémentaires spécifiques à la classe Man
	        Random random = new Random();
	        int degatsSupplementaires = random.nextInt(5) + 1; // Choix aléatoire entre 1 et 5
	        int currentHP = this.getHP();
	        currentHP -= degatsSupplementaires;
	        this.setHP(currentHP);
	        System.out.println("Lost " + degatsSupplementaires + " additional HP. Current HP: " + this.getHP());
	        
	        // Vérifier si le personnage est mort
	        if (this.getHP() <= 0) {
	            mourir(); // Appeler la méthode mourir() si les points de vie atteignent 0 ou moins
	        }
	    }
	public String move() {
		boolean sortir = false;
		System.out.println("The adventurer confronts four doors, each a portal to a different realm.\r"
				+ "which way are you gonna take ? (N, E, S or W)");
		String direction = keyboard.enterKeyboardString();
		while (sortir) {
			System.out.println("please enter a correct direction (N, E, S or W)");
			direction = keyboard.enterKeyboardString();
			sortir = (!direction.equals("N")) && (!direction.equals("E")) && (!direction.equals("S")) && (!direction.equals("W"));
		}
		// Appeler la méthode perdreVie() pour perdre un point de vie à chaque tour
		perdreVie();
		return direction;
	}

	public void showStats() {
		System.out.println("+------------------+");
		System.out.println("|       STATS      |");
		System.out.println("+------------------+");
		System.out.println("| Name : " + this.getName() + "   |");
		System.out.println("| HP : " + this.getHP() + "          |");
		System.out.println("| " + this.getPos().toString() + "|");
		System.out.println("+------------------+\n");
	}
	
	@Override
	public String toString() {
		return "Welcome to the maze, \u001B[34m"+ this.getName() + "\u001B[0m.\r\n"
				+ " May your heart be filled with courage and your steps guided \r\n"
				+ "by hope as you embark on this perilous journey.";
	}

}
