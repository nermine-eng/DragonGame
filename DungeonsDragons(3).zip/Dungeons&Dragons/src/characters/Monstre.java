package characters;

import java.util.Random;

public class Monstre extends LivingBeing {

    private static final int BASE_DAMAGE = 1; // Dégâts de base infligés à chaque tour
    private static final int EXTRA_DAMAGE = 5; // Dégâts supplémentaires spécifiques à la classe Monstre
    private static final int MAX_HP = 5; // Points de vie maximum d'un monstre
    private static final int HP_GAIN = 1; // Points de vie gagnés par le vainqueur d'un combat

    public Monstre(String _name) {
        super(MAX_HP, _name);
    }

    public void attaquer(Man man) {
        // Appeler la méthode perdreVie() de la classe mère pour effectuer les dégâts de base
        super.perdreVie();

        // Ajouter des dégâts supplémentaires spécifiques à la classe Monstre
        Random random = new Random();
        int degatsSupplementaires = random.nextInt(EXTRA_DAMAGE) + 1; // Choix aléatoire entre 1 et EXTRA_DAMAGE
        int currentHP = man.getHP();
        currentHP -= degatsSupplementaires;
        man.setHP(currentHP);
        System.out.println("Le monstre " + this.getName() + " inflige " + degatsSupplementaires + " dégâts supplémentaires à " + man.getName() + ". Points de vie restants : " + man.getHP());

        // Vérifier si le personnage est mort
        if (man.getHP() <= 0) {
            man.mourir(); // Appeler la méthode mourir() de la classe Man si les points de vie atteignent 0 ou moins
        }
    }

    @Override
    public void mourir() {
        System.out.println("Le monstre " + this.getName() + " est mort.");
    }

    public void gagnerCombat() {
        this.setHP(this.getHP() + HP_GAIN); // Ajouter les points de vie gagnés par le vainqueur
        System.out.println("Le monstre " + this.getName() + " gagne le combat et récupère " + HP_GAIN + " point de vie.");
    }
}
